# BDIX PLAY TV — metadata-only GitHub Actions

This package is **not** a streaming proxy, playback updater, or production deployment.

## Setup

1. Initialize the empty `rmia41735-commits/BDIX-Live-TV` repository on GitHub by creating a README on its `main` branch.
2. Upload the package contents to the repository root, preserving `.github/workflows/update-playlist-metadata.yml`.
3. In repository Settings → Actions → General → Workflow permissions, grant **Read and write permissions** if needed for committing generated metadata.
4. Open Actions → Update Playlist Metadata → Run workflow.
5. Check `generated/channels.json` and workflow logs. Subsequent scheduled runs occur every 3 hours (UTC); GitHub may delay scheduled starts.

## Data boundaries

`metadata/channels.json` contains only channel names and categories from the supplied playlists. It deliberately excludes URLs, headers, cookies, tokens, DRM keys, logos, and any stream access data. `scripts/build_metadata.py` rejects any additional fields. Output is deterministic, deduplicated, and commits only on actual metadata changes. No calls to Supabase or Vercel are made.

If the GitHub repository is linked to a Vercel project later, configure its deployment settings deliberately before enabling automatic deployments.
